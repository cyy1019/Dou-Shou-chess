package view;

import model.PlayerColor;

        import javax.swing.*;
        import java.awt.*;

/**
 * This is the equivalent of the ChessPiece class,
 * but this class only cares how to draw Chess on ChessboardComponent
 */
public class Component extends JComponent {

}

